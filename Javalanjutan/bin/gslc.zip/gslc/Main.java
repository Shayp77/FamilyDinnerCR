package gslc;
import java.util.*;
public class Main {
	ArrayList<Listproduct> list=new ArrayList<>();
	ArrayList<Equipment> arm=new ArrayList<>();
	
	Scanner scan=new Scanner(System.in);
	int choice=0;
	String name;
	String rarity;
	int level;
	int price;
	int point;
	String type;
	boolean flag=false;
	public static void main(String[] args) {
		new Main();
	}
	public Main() {
		do {
			System.out.println("Choose Category");
			System.out.println("=========================");
			System.out.println("1. Add new item");
			System.out.println("2. View  item list");
			System.out.println("3. Remove item from the list");
			System.out.println("Exit");
			System.out.print(">> :");
			choice=scan.nextInt();
			scan.nextLine();
			switch(choice) {
			case 1:
				Addlist();
			break;
			case 2:
				viewlist();
			break;
			case 3:
				deletelist();
			}
		}while(choice!=4);
		
	}
	public void addweapon() {
		do {
			System.out.print("Input the weapon name [Minimum 3 words, Maximum 25 words]:");
			name=scan.nextLine();
			if(name.length()>=3 && name.length()<=25) {
				flag=true;			
			}
			
		}while(flag==false);
		flag=false;
		do {
			System.out.print("Input the weapon rarity[Common | Rare | Epic | Legendary]");
			rarity=scan.nextLine();
			if(rarity.equals("Common") || rarity.equals("Rare") || rarity.equals("Epic") || rarity.equals("Legendary") ) {
				flag=true;
			}
		}while(flag==false);
		flag=false;
		do {
			System.out.print("Input the weapon level [Minimum 1, Maximum 1000]:");
			level=scan.nextInt();
			scan.nextLine();
			if(level>=1 && level<=1000) {
				flag=true;
			}
		}while(flag==false);
		flag=false;
		do {
			System.out.print("Input the weapon price[Minimum 1000, Maximum 9999999]:");
			price=scan.nextInt();
			scan.nextLine();
			if(price>=1000 && price<=9999999) {
				flag=true;
			}
		}while(flag==false);
		flag=false;
		do {
			System.out.print("Input the weapon attack point [Minimum 1, Maximum 9999]:");
			point=scan.nextInt();
			scan.nextLine();
			if(point>=1 && point<=9999) {
				flag=true;
			}
		}while(flag==false);
		type="weapon";
		list.add(new Listproduct(name, new Equipment(rarity,level,type,price,point)));
	}
	public void addarmor() {
		do {
			System.out.print("Input the weapon name [Minimum 3 words, Maximum 25 words]:");
			name=scan.nextLine();
			if(name.length()>=3 && name.length()<=25) {
				flag=true;			
			}
			
		}while(flag==false);
		flag=false;
		do {
			System.out.print("Input the weapon rarity[Common | Rare | Epic | Legendary]");
			rarity=scan.nextLine();
			if(rarity.equals("Common") || rarity.equals("Rare") || rarity.equals("Epic") || rarity.equals("Legendary") ) {
				flag=true;
			}
		}while(flag==false);
		flag=false;
		do {
			System.out.print("Input the weapon level [Minimum 1, Maximum 1000]:");
			level=scan.nextInt();
			scan.nextLine();
			if(level>=1 && level<=1000) {
				flag=true;
			}
		}while(flag==false);
		flag=false;
		do {
			System.out.print("Input the weapon price[Minimum 1000, Maximum 9999999]:");
			price=scan.nextInt();
			scan.nextLine();
			if(price>=1000 && price<=9999999) {
				flag=true;
			}
		}while(flag==false);
		flag=false;
		do {
			System.out.print("Input the weapon attack point [Minimum 1, Maximum 9999]:");
			point=scan.nextInt();
			scan.nextLine();
			if(point>=1 && point<=9999) {
				flag=true;
			}
		}while(flag==false);
		type="armor";
		list.add(new Listproduct(name, new Equipment(rarity,level,type,price,point)));
	}
	public void Addlist() {
		System.out.println("Choose category");
		System.out.println("========================");
		System.out.println("1. Add new weapon");
		System.out.println("2. Add new armor");
		System.out.println("3. Back");
		System.out.print(">> :");
		choice=scan.nextInt();
		scan.nextLine();
		switch(choice) {
		case 1:
			addweapon();
			break;
		case 2:
			addarmor();
			break;
		case 3:
			System.out.println("Back to main page");
			System.out.println("press enter to continue...");
			scan.nextLine();
			return;
		}
	}
	public void viewlist() {
		if(list.size()==0) {
			System.out.println("There is no item available!, Add some item by pressing 1 and follow the instruction");
			System.out.println("Press enter to continue");
			scan.nextLine();
			return;
		}else {
			System.out.println("No. | Item Name\t\t| Level\t | Rarity\t\t | Item type\t | att/def pts\t| price");
			System.out.println("=============================================================================================");
			for(int i=0;i<list.size();i++) {
				if(list.get(i).getEp().getRarity().equals("Legendary")) {
					System.out.println(i+1+".  | " + list.get(i).getName()+"\t\t| "+list.get(i).getEp().getLevel()+"\t | "+
							list.get(i).getEp().getRarity()+"\t\t | "+list.get(i).getEp().getType()+	"\t | "+ list.get(i).getEp().getPoint()+
							"\t\t | "+list.get(i).getEp().getPrice());
				}else {
					System.out.println(i+1+".  | " + list.get(i).getName()+"\t\t| "+list.get(i).getEp().getLevel()+"\t | "+
							list.get(i).getEp().getRarity()+"\t\t\t | "+list.get(i).getEp().getType()+	"\t | "+ list.get(i).getEp().getPoint()+
							"\t\t | "+list.get(i).getEp().getPrice());
				}
				
			}
		} 
	}
	public void deletelist() {
		if(list.size()==0) {
			System.out.println("There is no item available!, Add some item by pressing 1 and follow the instruction");
			System.out.println("Press enter to continue");
			scan.nextLine();
			return;
		}
		viewlist();
		
		int idx=-1;
		System.out.println("Press enter to continue");
		scan.nextLine();
		System.out.print("Input the number of equipment to delete [1-2]:");
		idx=scan.nextInt();
		scan.nextLine();
		if(idx<0 || idx>list.size()) {
			System.out.println("There is no equipment with that number try again");
			System.out.println("Press enter to continue..");
			scan.nextLine();
			return;
		}else {
			list.remove(idx-1);
			System.out.println("item succesfully deleted!");
			System.out.println("Press enter to continue..");
			scan.nextLine();
		}
	}
}

