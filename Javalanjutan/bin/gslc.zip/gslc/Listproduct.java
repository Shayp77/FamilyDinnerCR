package gslc;

public class Listproduct {
	private String name;
	private Equipment ep;
	Listproduct(String name,Equipment ep){
		this.name=name;
		this.ep=ep;
	}

	public Equipment getEp() {
		return ep;
	}

	public void setEp(Equipment ep) {
		this.ep = ep;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
		
	}
	
}
