package gslc;

public class Equipment {
	private String rarity;
	private int level;
	private int price;
	private String type;
	private int point;
	Equipment(String rarity,int level,String type ,int price,int point) {	
		this.rarity=rarity;
		this.level=level;
		this.type=type;
		this.price=price;
		this.point=point;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getRarity() {
		return rarity;
	}
	public String getType() {
		return type;
	}
	public void setRarity(String rarity) {
		this.rarity = rarity;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getPoint() {
		return point;
	}
	public void setPoint(int point) {
		this.point = point;
	}

	
}
